console.log("channels.js");

//localStorage.setItem('mychannel_id', '004');


//localStorage.setItem('mychannel_id','008');
var mychannel_id = "null";


 

var channels_all_deta = [

  { id: "000", channel_name: "Love story couples", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "abcd_0001", email: "love@gmail.com", channels_poster: "" },

  { id: "001", channel_name: "feel song", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "abcd_0001", email: "", channels_poster: "" },

  { id: "002", channel_name: "egale", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "zyxw_0002", email: "", channels_poster: "" },

  { id: "003", channel_name: "visualtechnology", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", },

  { id: "004", channel_name: "hindutva", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },

  { id: "005", channel_name: "study", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },

  { id: "006", channel_name: "sheetaram", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },

  { id: "007", channel_name: "Lively music", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },
  { id: "008", channel_name: "beet trend", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },
  { id: "009", channel_name: "dj mixing bass", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },
  { id: "010", channel_name: "web hosting", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },
  { id: "011", channel_name: "code_all", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "", email: "", channels_poster: "" },
  { id: "012", channel_name: "Vishal ahirwar", channels_img: "https://images.unsplash.com/photo-1493612276216-ee3925520721?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFuZG9tfGVufDB8fDB8fHww", discription: "this is discription", password: "001", email: "vishalahirwarguna123@gmail.com", channels_poster: "" },

  ]