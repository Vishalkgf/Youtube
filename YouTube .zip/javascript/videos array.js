console.log('videos array.js');

var videos = [
 { id: "v_01",like:like("v_01",1),dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "Awadh Mein Ram Aaye Hai - Slowed   Lofi ft.Jaya Kishori _ After Remix", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "000" },

  { id: "v_02", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "सिया राम कह दिया है ||  Rajan Ji Maharaj_Ram Katha Bhajan With Lyrics_ राजन जी महाराज(MP3_160K)", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "001" },

  { id: "v_03", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "Pata Nahi Kis Roop Me Aakar Narayan Mil Jayega (Full Song) _ Narci _ Ram Darshan", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "002" },

  { id: "v_04", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "lord Krishna status video", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "003" },


  { id: "v_05", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "lord Krishna status video(360P)", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "000", channel_id: "004" },

  { id: "v_06", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "radha raman status video(360P)", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "005" },

  { id: "v_07", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "Awadh Mein Ram Aaye Hai - Slowed   Lofi ft.Jaya Kishori _ After Remix", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "006" },

  { id: "v_08", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "radha raman Hari govind chali trending whatsapp status", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "007" },

  { id: "v_09", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "Papa -- -- FathersDay", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "008" },

  { id: "v_10", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "Musk man attack the rock _bodybuilder _wwe2k22 _wweraw _wweshorts __therock _kaigreen _wwe_shorts", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "009" },

  { id: "v_11", like: like("v_01", 1), dislike:like("v_01",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "lord Krishna status video", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "010" },

  { id: "v_12", like: like('v_12',1), dislike:like("v_12",0), discription: "", src: "https://drive.google.com/?id=1-6kiDUZqI0qjxrZL4Uf5P8qC_imu3FM1", video_name: "lord Krishna status video", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "011" },
  
  { id: "v_13", like: like('v_12',1), dislike:like("v_12",0), discription: "", src: "https://www.w3schools.com/tags/movie.mp4", video_name: "मंदोदरी ने रावण को थप्पड़ क्यों मारा _ _ बागेश्वर धाम सरकार _ Bageshwar Dham Sarkar", thumbnail: " https://images.unsplash.com/photo-1511795373793-50cf415cad56?w=700&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGRpc3BsYXklMjBmb3RvfGVufDB8fDB8fHww", channel_id: "012" },

  ]



