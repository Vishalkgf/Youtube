var all_like = [
  { video_id: "v_01", liker_id: "001", like: 1, },
  { video_id: "v_01", liker_id: "002", like: 1, },
  { video_id: "v_01", liker_id: "003", like: 1, },
  { video_id: "v_01", liker_id: "005", like: 1, },

  { video_id: "v_02", liker_id: "001", like: 1, },
  { video_id: "v_02", liker_id: "002", like: 1, },
  { video_id: "v_02", liker_id: "003", like: 1, },
  { video_id: "v_02", liker_id: "005", like: 1, },
  { video_id: "v_02", liker_id: "006", like: 1, },

  { video_id: "v_03", liker_id: "001", like: 1, },
  { video_id: "v_03", liker_id: "002", like: 1, },

  { video_id: "v_04", liker_id: "003", like: 1, },
  { video_id: "v_04", liker_id: "005", like: 1, },

  { video_id: "v_05", liker_id: "001", like: 1, },
  
  { video_id: "v_06", liker_id: "002", like: 1, },
  { video_id: "v_06", liker_id: "003", like: 1, },
  { video_id: "v_06", liker_id: "005", like: 1, },

  { video_id: "v_07", liker_id: "005", like: 1, },
 
  { video_id: "v_08", liker_id: "005", like: 1, },
  { video_id: "v_08", liker_id: "006", like: 1, },
  { video_id: "v_08", liker_id: "007", like: 1, },

  { video_id: "v_09", liker_id: "008", like: 1, },
  ]

function like(v_id, lc) {
  let l = all_like.filter(a => a.video_id == v_id);
  let a = l.filter(a => a.like == lc);
  return a.length;
}

