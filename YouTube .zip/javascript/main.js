console.log("main.js");


shortdiv.forEach((e) => {
  e.addEventListener('click', () => {
    shortplaydiv.classList.remove("none");
  })
})
shortplaydiv.addEventListener('scroll', () => {
  short_video.forEach((e) => {
    e.pause();
  })
})

short_video_display.forEach((e) => {
  e.addEventListener('click', () => {
    if (short_video[e.id].paused) {
      short_video[e.id].play();
    } else {
      short_video[e.id].pause();
    }
    setInterval(() => {
      short_div_range[e.id].value = Math.floor(short_video[e.id].currentTime * 100 / short_video[e.id].duration);
    })
  })
})





//box();



home_bottom_btn[0].addEventListener('click', (e) => {
  removing(content);
  home_bottom_btn[0].classList.add("tab_hover")
})
home_bottom_btn[1].addEventListener('click', (e) => {
  shortplaydiv.classList.remove("none");
})
home_bottom_btn[2].addEventListener('click', (e) => {
  uploads.classList.remove("none")
  //home_bottom_btn[2].classList.add("tab_hover")
})
home_bottom_btn[3].addEventListener('click', (e) => {
  removing(subscription);
  home_bottom_btn[3].classList.add("tab_hover")
})
home_bottom_btn[4].addEventListener('click', (e) => {
  removing(library_contener);
  home_bottom_btn[4].classList.add("tab_hover")
})

home_bottom_btn[0].addEventListener('dblclick', (e) => {
  content_video();
  box_f();
})
home_bottom_btn[3].addEventListener('dblclick', (e) => {
remove_subscriptions_removal();
})




setInterval(() => {
  let haur = Math.floor(viewing_video.currentTime / 60 / 60);
  let minutes = Math.floor((viewing_video.currentTime / 60) - haur * 60);
  let second = Math.floor(viewing_video.currentTime - minutes * 60 - haur * 60 * 60);
  current_timings.innerText = minutes + ":" + second;
  let du_h = Math.floor(viewing_video.duration / 60 / 60);
  if (0 < du_h) {
    if (haur < 1) {
      haur = "0:";
    } else {
      haur = haur + ":";
    }
  } else {
    if (haur < 1) {
      haur = "";
    } else {
      haur = haur + ":";
    }
  }

  if (minutes < 10) {
    minutes = "0" + minutes + ":";
  }
  else {
    minutes = minutes + ":";
  }

  if (second < 10) {
    second = "0" + second;
  } else {
    second = second;
  }

  current_timings.innerText = haur + minutes + second;


  range.value = Math.floor(viewing_video.currentTime * 100 / viewing_video.duration);
}, 60);


range.addEventListener('change', () => {
  viewing_video.currentTime = Math.floor(viewing_video.duration * range.value / 100);
})

viewing_video.addEventListener('durationchange', () => {
  let hour = Math.floor((viewing_video.duration / 60) / 60);
  let minutes = Math.floor((viewing_video.duration / 60) - hour * 60);

  let second = Math.floor(viewing_video.duration)
  second = Math.floor(second - minutes * 60 - hour * 60 * 60);

  if (hour < 1) {
    hour = "";
  } else { hour = hour + ":" }

  if (second < 10) {
    second = "0" + second
  }
  if (minutes < 10) {
    minutes = "0" + minutes + ":";
  } else { minutes = minutes + ":" }
  p_duration.innerText = hour + minutes + second;

  //create_div_box(viewing_list, viewing_video.poster, viewing_channel_img.src, viewing_channel_name.innerText, viewing_name.innerText, viewing_video.src, viewing_video.getAttribute("channel_id"));
//  create_div_box(history_contener, viewing_video.poster, viewing_channel_img.src, viewing_channel_name.innerText, viewing_name.innerText, viewing_video.src, viewing_video.getAttribute("channel_id"));

history.push({video_id:viewing_video.getAttribute("channel_id")},);
  console.log(history.length, "history");
})

let history_contener = document.getElementsByClassName("history_contener")[0]
let main_div_history = document.getElementsByClassName("history")[0];

full_display_history_btn.addEventListener('click', () => {
  full_display_history();
})


window.addEventListener('online', () =>{
 offline_div.forEach((e)=>{
   e.classList.add("none");
   document.body.removeChild(icon_link);
   document.body.appendChild(icon_link);
 })
});
window.addEventListener('offline', () =>{
   offline_div.forEach((e)=>{
   e.classList.remove("none");
 })
});



setTimeout(()=>{
a=localStorage.getItem("mychannel_id");
if (a==null || a=="null"){
  console.log("null logs");
} else {
  mychannel_id = localStorage.getItem("mychannel_id");
  autosetmychannel(mychannel_id);
}
},200)



subscription_channel_video()

 box_f();
 
