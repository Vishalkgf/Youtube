console.log("array.js");

let subscription_channel = [
  { channel_id: "000" },
  { channel_id: "001" },
  { channel_id: "002" },
  ]






let content = document.getElementsByClassName("content")[0];




//let b= videos.filter(n=>n.channel_id=="000");
//console.log(b);


let history = [
  { video_id: "v_10" },
  ]


removing(content);
content_video();