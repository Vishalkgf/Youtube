console.log("functions.js");

function full_display_history() {
  let a = main_div_history.classList[1];
  if ("full_display_history" == a) {
    main_div_history.classList.remove("full_display_history");
    full_display_history_btn.innerHTML = "<i class='fa fa-history'></i> view all"
  } else {
    main_div_history.classList.add("full_display_history");
    full_display_history_btn.innerHTML = "  <i class='fa fa-history'></i> close"
  }
}

function start() {
  let video_cam_view = document.getElementsByClassName("video_cam_view")[0];
  if (navigator.mediaDevices.getUserMedia) {
    navigator.mediaDevices.getUserMedia({ video: { facingMode: "usr" }, audio: true }).then(function(s) {
      video_cam_view.srcObject = s;
    });
  }
}


function removing(display) {
  let check0 = content.classList[1];
  let check1 = library_contener.classList;
  let check2 = subscription.classList;
  if ("none" == check0) {} else {
    content.classList.add("none")
  }
  if ("none" == check1) {} else {
    library_contener.classList.add("none")
  }
  if ("none" == check2) {} else {
    subscription.classList.add("none");
  }

  home_bottom_btn.forEach((e) => {
    e.classList.remove("tab_hover");
  })
  display.classList.remove("none");

}

function open_rightmenuslider(a) {
  rightmenuslider.classList.remove("none");
}

function close_rightmenuslider(a) {
  rightmenuslider.classList.add("none");
}

var box_f = function box() {
  let box = Array.from(document.getElementsByClassName("box"));
  box.forEach((e) => {
    e.addEventListener('click', () => {
      only_watching();
      let check
      let div = e;
      let video_id = div.getAttribute("video_id");

      if (video_id == viewing_video.getAttribute("channel_id")) {} else {
        get_waching_Deta(video_id);
      }
      viewing_video.setAttribute('channel_id', video_id);

      /* 

            subscription_channel.forEach((e) => {
              if (e.channel_id == channel_id) {
                check = "already subscribed";
              }
            })
            if ("already subscribed" == check) {
              subscribe_btn.innerText = "subscribed";
              subscribe_btn.classList.add("subscribed");
            } else {
              subscribe_btn.innerText = "subscribe";
              subscribe_btn.classList.remove("subscribed");
            }
                 */
      setTimeout(() => {
       playposeicon.click();
      }, 600)
    })
  })
}

function only_watching() {
  watching.classList.remove("none");
  watching.classList.remove("bottom_watching");
}

function close_uploads() {
  let uploads = document.getElementsByClassName("uploads")[0];
  uploads.classList.add("none");
}

function subscribe(channel_id) {
  let check
  let id = channel_id;
  subscribe_btn.setAttribute('disable', 'disable');
  let channel = channels_all_deta.filter(n => n.id == channel_id)
  let video_list = videos.filter(n => n.channel_id == channel_id)

  subscription_channel.forEach((e) => {
    if (channel_id == e.channel_id) {
      check = "already subscribed";
    }
  })

  if ("already subscribed" == check) {
    console.log("unsubscribed");
    setTimeout(() => {
      let index = subscription_channel.findIndex(n => n.channel_id == id);
      console.log(index);
      delete subscription_channel[index];
      subscribe_btn.innerText = "subscribe";
      subscribe_btn.classList.remove("subscribed");
    }, 600)

  } else {
    subscription_channel.push({ channel_id: channel_id }, );
    subscribe_btn.innerText = "subscribed";
    subscribe_btn.classList.add("subscribed");
    channel_div(subscription.getElementsByClassName("nav")[0], channel[0].channels_img);
    video_list.forEach((e, i) => {
      create_div_box(subscription.getElementsByClassName("contener")[0], video_list[i].thumbnail, channel[0].channels_img, channel[0].channel_name, video_list[i].video_name, video_list[i].src, channel_id);
    })
  }
}





function channel_div(append, channel_img, channel_id) {
  let div = document.createElement("div");
  let img = document.createElement("img");
  div.setAttribute('class', 'channel_div');
  img.setAttribute('src', channel_img);
  img.setAttribute('channel_id', channel_id);
  div.append(img);
  append.append(div)
}


function create_div_box(append, thumbnail_src, channel_img, channel_name, video_name, video_src, channel_id, video_id) {
  let box = document.createElement("div");
  box.setAttribute('class', 'box');
  box.setAttribute('video_id', video_id);
  box.innerHTML = ["<img class='thumbnail load-animi' src='" + thumbnail_src + "'><div><img class='img-lods' src='" + channel_img + "'><ul><li>" + video_name + "</li><li>" + channel_name + "</li></ul><i class='fa fa-ellipsis-v'></i></div>"]
  append.append(box);
}

function viewing_video_download() {
  let download = document.createElement("a");
  download.setAttribute('download', viewing_video.src);
  download.setAttribute('href', viewing_video.src);
  download.click();
}

function remove_subscriptions_removal() {
  let a = Array.from(subscription.getElementsByClassName("box"));
  let b = Array.from(subscription.getElementsByClassName("channel_div"));
  // a.filter(n=>n.getAttribute("channel_id")==c_id);
  //console.log(a[0]);
  a.forEach((e) => { e.remove() })
  b.forEach((e) => { e.remove() })
  setTimeout(() => {
    subscription_channel_video()
  }, 800)
}

function remove_content_video() {
  let a = Array.from(content.getElementsByClassName("box"));
  let b = Array.from(content.getElementsByClassName("spinner"));
  a.forEach((e) => { e.remove() })
  b.forEach((e) => { e.remove() })
}

function content_video() {
  remove_content_video();
  videos.forEach((e, i) => {
    let channel = channels_all_deta.filter(n => n.id == e.channel_id)
    create_div_box(content, e.thumbnail, channel[0].channels_img, channel[0].channel_name, e.video_name, e.src, e.channel_id, e.id);
  })
}

function subscription_channel_video() {
  for (var i = 0; i < subscription_channel.length; i++) {
    let channel_id = subscription_channel[i].channel_id;
    let channel = channels_all_deta.filter(n => n.id == channel_id);
    let channel_videos_list = videos.filter(n => n.channel_id == channel_id);

    channel_div(subscription.getElementsByClassName("nav")[0], channel[0].channels_img, channel[0].id);

    channel_videos_list.forEach((e, i) => {
      create_div_box(subscription.getElementsByClassName("contener")[0], channel_videos_list[i].thumbnail, channel[0].channels_img, channel[0].channel_name, channel_videos_list[i].video_name, channel_videos_list[i].src, channel[0].id, channel_id);
    })

  }
}

function autosetmychannel(c_id) {
  let channel = channels_all_deta.filter(n => n.id == c_id)[0];
  profile_logo[0].src = channel.channels_img;
  my_channel_id.innerText = channel.id;
  my_channel_name.innerText = channel.channel_name;
  profile_logo[1].src = profile_logo[0].src;
  profile_logo[2].src = profile_logo[1].src;
}

if (mychannel_id == !"null") {
  autosetmychannel(mychannel_id);
}



function view_mychannel() {
  ope_channel_main(mychannel_id);
}

function ope_channel_main(channel_id) {
  close_rightmenuslider();
  view_channel_main[0].classList.remove("none");
  view_channel(channel_id)
  if ("bottom_watching" != watching.classList) {
    watching.classList.add("bottom_watching");
  }
}

function clos_channel_main() {
  view_channel_main[0].classList.add("none");
}

function view_channel(channel_id) {
  let channel_img = view_channel_main[0].getElementsByClassName("channel_img");
  let channel_name = view_channel_main[0].getElementsByClassName("channel_name");
  let channel_about = view_channel_main[0].getElementsByClassName("channel_about");
  let channel = channels_all_deta.filter(n => n.id == channel_id)[0]
  channel_img[0].src = channel.channels_img;
  channel_name[0].innerText = channel.channel_name;
  channel_about[0].innerText = channel.discription;
  view_channel_main[0].getElementsByClassName("nav_box")[0].style.backgroundImage = "url(" + channel.channels_poster + ")";
  view_channel_main[0].getElementsByClassName("nav_box")[0].getElementsByClassName("subscribe_btn")[0].setAttribute('onclick', 'subscribe(' + channel_id + ')');
}


function send_video_Comment() {
  let mss = video_comment_input.value;
  let channel = channels_all_deta.filter(n => n.id == mychannel_id)[0];
  if (0 == mss) {
    console.log("not send");
    alert("enter comment")
  } else {
    let div = document.createElement("div");
    div.setAttribute('class', 'massage_channel_div');
    div.innerHTML = "<img src='" + channel.channels_img + "'><ul><p class='c_name'>" + channel.channel_name + "</p><p class='c_comment'>" + mss + "</p></ul>";
    comments_box_mss_box.append(div);
    video_comment_input.value = "";
  }
}

document.body.onkeydown = function(key) {
  console.log(key.keyCode);
  if (13 == key.keyCode) {
    send_video_Comment()
  }
}

function open_comment_box(v_id) {
  if ("none" == comments_box.classList[1]) {
    comments_box.classList.remove("none");
    comment(v_id);
  }
  else {
    close_comment_box();
  }
}

function close_comment_box() {
  comments_box.classList.add("none");
}

function get_waching_Deta(v_id) {
  let video = videos.filter(a => a.id == v_id)[0];
  let channel = channels_all_deta.filter(a => a.id == video.channel_id)[0];
  let like = video.like;
  let dislike = video.dislike;
  let src = video.src;
  let thumbnail = video.thumbnail;
  let name = video.video_name;
  let c_name = channel.channel_name;
  let c_img = channel.channels_img;
  viewing_name.innerText = name;
  video_name.innerText=name;
  viewing_channel_img.src = c_img;
  viewing_channel_name.innerText = c_name;
  viewing_channel_img.setAttribute('onclick', 'ope_channel_main(' + channel.id + ')');
  viewing_channel_name.setAttribute('onclick', 'ope_channel_main(' + channel.id + ')');
  subscribe_btn.setAttribute('onclick', 'subscribe(' + channel.id + ')');
  viewing_video.src = src;
  viewing_video.poster = thumbnail;
  like_i.innerText = like;
  dislike_i.innerText = dislike;
  commentsBtn.setAttribute('onclick', 'open_comment_box("' + v_id + '")');
}

function comment(v_id) {
  clear_comm()
  let a = all_comments.filter(a => a.V_id == v_id);
  console.log(a);
  setTimeout(() => {
    a.forEach((e) => {
      let channel = channels_all_deta.filter(a => a.id == e.com_channel_id)[0];
      let c_img = channel.channels_img;
      let c_name = channel.channel_name;
      create_CommentSms(c_img, c_name, e.comment);
    })
  }, 206)

}


function create_CommentSms(c_img, c_name, mss) {
  let div = document.createElement("div");
  let img = document.createElement("img");
  let ul = document.createElement("ul");
  let C_name = document.createElement("p");
  let C_mms = document.createElement("p");
  img.setAttribute('src', c_img);
  C_name.setAttribute('class', 'c_name');
  C_mms.setAttribute('class', 'c_comment');
  C_name.innerText = c_name;
  C_mms.innerText = mss;
  div.setAttribute('class', 'massage_channel_div');
  ul.append(C_name, C_mms);
  div.append(img, ul)
  comments_box_mss_box.append(div);
}

function clear_comm() {
  let a = comments_box_mss_box
  let aa = Array.from(a.getElementsByClassName("massage_channel_div"))
  aa.forEach((e) => { e.remove() })
}


function viewchannel_seting() {
  let div = document.getElementsByClassName("setting")[0];
  div.classList.remove('none');
  let video = viewing_video;
  video.pause();
  playposeicon.classList.remove("fa-pause-circle");
  playposeicon.classList.add("fa-play-circle");
}

function viewchannel_seting_close() {
  let div = document.getElementsByClassName("setting")[0];
  div.classList.add('none')
  removing(content);
}

let theme_link = document.getElementById("theme_link");

function save_setting() {
  let language = document.getElementById("language");
  let theme = document.getElementById("theme").value;
  let timmer = document.getElementById("timmer");
  let download = document.getElementById("download");

  let localtheme = localStorage.getItem("theme");
  if (localtheme == theme) {
    console.log("all sets ting");
  } else {
    themeset(theme);
  }

}

function themeset(a) {
  if (a == "default") {
    theme_link.setAttribute('href', '/themes/default.css');
    localStorage.setItem('theme', 'default');
  }
  if (a == "dark") {
    theme_link.setAttribute('href', '/themes/dark.css');
    localStorage.setItem('theme', 'dark');

  }
}

//save_setting();

if (localStorage.getItem("theme") == "default") {
  themeset("default")
}
if (localStorage.getItem("theme") == "dark") {
  themeset("dark")
}

function watchingplaypause(a) {
  if (a == "play") {
    playposeicon.forEach((e) => {
      viewing_video.play();
      console.log(e.classList);
      e.classList.remove("fa-play-circle");
      e.classList.add("fa-pause-circle");
    })
  }
}

playposeicon.addEventListener('click', () => {
  if (viewing_video.paused) {
    viewing_video.play();
    playposeicon.classList.remove("fa-play-circle");
    playposeicon.classList.add("fa-pause-circle");
    bottom_watching_playpouseicon.classList.remove("fa-play-circle");
    bottom_watching_playpouseicon.classList.add("fa-pause-circle");

  }
  else {
    viewing_video.pause();
    playposeicon.classList.remove("fa-pause-circle");
    playposeicon.classList.add("fa-play-circle");
    bottom_watching_playpouseicon.classList.remove("fa-pause-circle");
    bottom_watching_playpouseicon.classList.add("fa-play-circle");
  }
})

function share_video_btn(){
 let share=document.getElementById("share");
if (share.className=="none") {
  share.classList.add("share");
}else{
  share.classList.remove("share");
}
}
function getfullscreen(){
 return   document.fullscreenElement
        || document.webkitfullscreenElement
        || document.mozfullscreenElement
        || document.msfullscreenElement;
}
function full_screen_toggle(){
    if (getfullscreen()) {
      document.exitFullscreen();
    }
    else{
       document.getElementById("display").requestFullscreen();
     console.log();
    }
}

