<?php

$servername = "localhost";
$username = "root";
$passworD = "root";
$detabase ="YouTube";
// Create connection
$conn = mysqli_connect($servername, $username, $passworD,$detabase);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " /* .$conn->connect_error*/);
}

echo "Connected successfully";


?>