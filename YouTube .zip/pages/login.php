<?php


$servername = "localhost";
$username = "root";
$passworD = "root";
$detabase ="YouTube";
// Create connection
$conn = mysqli_connect($servername, $username, $passworD,$detabase);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " /* .$conn->connect_error*/);
}

echo "Connected successfully";


$name = $_POST["name"];
$email = $_POST["email"];
$password = $_POST["password"];

echo $name,$email,$password;

$sql = "INSERT INTO `Channels` (`Id`, `channel_name`, `channels_img`, `channels_poster`, `discription`, `password`, `email`) VALUES (NULL, '$name', '/mychannel/IMG.png', 'https://media.istockphoto.com/id/108150256/photo/little-girl-pointing-at-ducks-on-lake.webp?b=1&s=170667a&w=0&k=20&c=ayYPRdBJ-sbJtmPLEP9r_blkduzVatWqt8T4xznLVfc=', NULL, '$password', '$email');";

if ($sql==true) {
echo "login successful";
}
if ($sql->mysql_error()) {
 echo mysqli_error();
}

?>