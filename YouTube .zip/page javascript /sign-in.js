console.log("sign-in.js");

let BTN=document.getElementById("BTN");

BTN.addEventListener('click',()=>{
let email=document.getElementById("email");
let password=document.getElementById("password");
let name=document.getElementById("name");

let c_email=channels_all_deta.filter(n=>n.email==email.value);

if (c_email.length==!0) {
  if (c_email[0].password==password.value) {
   console.log("login successful"); 
 localStorage.setItem('mychannel_id',c_email[0].id);
 let a= document.createElement("a");
 a.setAttribute('href','/index.html');
   a.click();
  } else {
   alert("password incorrect");
  }
}else{
 if (email.value==0) {
          alert("type your email address")
 }else{
        alert("type your currect email address")
 }
}
})

window.onkeydown=(key)=>{
  if (key.keyCode==13) {
    BTN.click();
  }
}
